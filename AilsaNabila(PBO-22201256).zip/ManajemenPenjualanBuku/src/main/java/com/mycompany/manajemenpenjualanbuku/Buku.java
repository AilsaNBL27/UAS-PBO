/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.manajemenpenjualanbuku;

import java.time.chrono.ThaiBuddhistEra;

/**
 *
 * @author Sarah
 */
class Buku{
    private String judul;
    private String nomorEdisi;
    private int stok;
    private double harga;
    
    public Buku(String judul, String nomorEdisi, int stok, double harga){
        this.judul = judul;
        this.nomorEdisi= nomorEdisi;
        this.stok=stok;
        this.harga=harga;
    }
    
    public String getJudul(){
        return judul;
    }
    
    public String getNomorEdisi(){
        return nomorEdisi;
    }
    
    public void nomorEdisi(String nomorEdisi) {
        this.nomorEdisi = nomorEdisi;
    }
    
    public int  getStok () {
        return stok;
    }
    
    public void setStok (int stok) {
        this.stok = stok;
    }
    
    public double getHarga () {
        return harga;
    }
    
    public void setHarga (double harga) {
        this.harga = harga;
    }
}
    
