/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.manajemenpenjualanbuku;

/**
 *
 * @author Sarah
 */
public class ManajemenPenjualanBuku {
    private int stokBukuFiksi;
    private int stokBukuNonFiksi;
    private int Majalah;
    
public ManajemenPenjualanBuku(int stokMajalah) {
    stokBukuFiksi = 0;
    stokBukuNonFiksi = 0;
    stokMajalah = 0;
    }
}

